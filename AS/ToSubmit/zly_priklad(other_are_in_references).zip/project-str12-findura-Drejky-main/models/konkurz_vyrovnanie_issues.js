'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class konkurz_vyrovnanie_issues extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  konkurz_vyrovnanie_issues.init({
    cin: DataTypes.BIGINT
  }, {
    sequelize,
    modelName: 'konkurz_vyrovnanie_issues',
    schema: 'ov',
    timestamps: false
  });
  return konkurz_vyrovnanie_issues;
};