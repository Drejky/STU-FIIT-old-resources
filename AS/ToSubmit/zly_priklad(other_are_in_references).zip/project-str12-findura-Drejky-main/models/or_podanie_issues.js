'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class or_podanie_issues extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  or_podanie_issues.init({
    bulletin_issue_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    raw_issue_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    br_mark: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    br_court_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    br_court_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    kind_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    kind_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cin: DataTypes.BIGINT,
    registration_date: DataTypes.DATE,
    corporate_body_name: DataTypes.STRING,
    br_section: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    br_insertion: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    text: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    address_line: DataTypes.STRING,
    street: DataTypes.STRING,
    postal_code: DataTypes.STRING,
    city: DataTypes.STRING,
    company_id: DataTypes.BIGINT,
  }, {
    sequelize,
    modelName: 'or_podanie_issues',
    schema: 'ov',
    timestamps: false
  });
  return or_podanie_issues;
};