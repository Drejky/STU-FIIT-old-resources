'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class raw_issues extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  raw_issues.init({
    bulletin_issue_id: DataTypes.INTEGER,
    file_name: DataTypes.STRING,
    content: DataTypes.TEXT,
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    }, {
    sequelize,
    modelName: 'raw_issues',
    schema: 'ov',
    timestamps: false
  });
  return raw_issues;
};