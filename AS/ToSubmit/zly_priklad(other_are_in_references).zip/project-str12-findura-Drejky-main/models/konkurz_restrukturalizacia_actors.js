'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class konkurz_restrukturalizacia_actors extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  konkurz_restrukturalizacia_actors.init({
    cin: DataTypes.BIGINT
  }, {
    sequelize,
    modelName: 'konkurz_restrukturalizacia_actors',
    schema: 'ov',
    timestamps: false
  });
  return konkurz_restrukturalizacia_actors;
};