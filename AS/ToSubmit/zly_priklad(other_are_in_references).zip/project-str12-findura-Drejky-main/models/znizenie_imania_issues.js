'use strict';
const {
  Model, STRING
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class znizenie_imania_issues extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  znizenie_imania_issues.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey:true
    },
    bulletin_issue_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    raw_issue_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    corporate_body_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    street:DataTypes.STRING,
    building_number:DataTypes.STRING,
    postal_code:DataTypes.STRING,
    city:DataTypes.STRING,
    country:DataTypes.STRING,
    br_court_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    br_court_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    br_section: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    br_insertion: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cin: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    decision_text: DataTypes.TEXT,
    decision_date: DataTypes.DATE,
    equity_currency_code: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    old_equity_value: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    new_equity_value: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    resolution_store_date: DataTypes.DATE,
    first_ov_released_date: DataTypes.DATE,
    first_ove_released_number: DataTypes.STRING,
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    company_id:DataTypes.BIGINT
  }, {
    sequelize,
    modelName: 'znizenie_imania_issues',
    schema: 'ov',
    timestamps: false
  });
  return znizenie_imania_issues;
};