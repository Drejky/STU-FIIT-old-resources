//require('dotenv').config()
const express = require('express');
const { Sequelize, DataTypes, Model, Op, or } = require('sequelize');
//const sequelize = new Sequelize(process.env.DATABASE_URL);
const { sequelize} = require('./models')
const db = require('./models')
const app = express();
const port=process.env.PORT || 3000;
const dateFormat = require("dateformat");
const { createSolutionBuilderHost } = require('typescript');
//const raw_issues = require('./models/raw_issues')(Sequelize, DataTypes);

app.use(require('sanitize').middleware);

app.get('/', (req, res) => {
    res.redirect("https://fiit-dbs-xkudela-app.azurewebsites.net/v1/health")
})

app.get('/v1/health', async (req, res) => {
  const [results, metadata] = await sequelize.query("SELECT date_trunc('second', current_timestamp - pg_postmaster_start_time()) as uptime;")
  let resu = {
    'pgsql':
    {'uptime': `${results[0].uptime.days} days ${results[0].uptime.hours}:${results[0].uptime.minutes}:${results[0].uptime.days}`}
  };
  res.send(resu)
})

app.get('/v1/ov/submissions', async(req, res) => {
  let page = req.query.page;
  let per_page = req.query.per_page;
  let order_by = req.query.order_by;
  let order_type = req.query.order_type;
  let registration_date_lte = req.query.registration_date_lte;
  let registration_date_gte = req.query.registration_date_gte;
  let query = req.query.query;
  if(!page) page = 1
  if(!per_page) per_page = 10
  if(!order_by) order_by = "id"
  if(!order_type) order_type = "ASC"
  if(!registration_date_lte) registration_date_lte = '3000-06-17';
  else{
    const[foo, bar] = await sequelize.query(`select TO_DATE('${req.query.registration_date_lte}', 'iso')`)
    registration_date_lte = foo[0].to_date;
  }
  if(!registration_date_gte) registration_date_gte = '1000-01-01';
  else{
    const[foo, bar] = await sequelize.query(`select TO_DATE('${req.query.registration_date_gte}', 'iso')`)
    registration_date_gte = foo[0].to_date;
  }
  if(!query) query = ""

  console.log(page, per_page, order_by, order_type, registration_date_gte, registration_date_lte, query);

  lower_border = Number(per_page) * (Number(page) - 1);

  const [results, metadata] = await sequelize.query(`SELECT id, br_court_name, kind_name, cin, registration_date, corporate_body_name, br_section, 
  br_insertion, text, street, postal_code, city FROM ov.or_podanie_issues WHERE registration_date < '` + registration_date_lte +
   "'::date AND registration_date > '" + registration_date_gte + "'::date AND (corporate_body_name LIKE '%"+ query + "%' OR city LIKE '%" + query +
    "%' OR CAST(cin AS TEXT) LIKE '" + query+ "') ORDER BY " + order_by + " " + order_type + " offset " + lower_border + " ROWS FETCH FIRST " + per_page + " rows only");
  
  const [totalRes, meta] = await sequelize.query(`SELECT COUNT(*) FROM ov.or_podanie_issues WHERE registration_date <= '` + registration_date_lte +
   "' AND registration_date >= '" + registration_date_gte + "' AND (corporate_body_name LIKE '%"+ query + "%' OR city LIKE '%" + query +
    "%' OR CAST(cin AS TEXT) LIKE '" + query + "')");
  
    console.log(totalRes[0])

    toSend ={
      "items": results,
      "metadata": {
        "page": Number(page),
        "per_page": Number(per_page),
        "pages": Math.ceil(totalRes[0].count / per_page),
        "total": Number(totalRes[0].count)
      }
  }


  res.send(toSend);

})

app.use(express.json())
app.post('/v1/ov/submissions', async(req, res) =>{
  //Getting todays date
  let today = dateFormat(new Date(), "isoDateTime");

  //Validations
  errors = {
    "errors": []
  }
  if(!req.body.br_court_name) {
    errors.errors.push({
      "field": "br_court_name",
      "reasons":[
        "required"
      ]
    })
  }
  if(!req.body.kind_name) {
    errors.errors.push({
      "field": "kind_name",
      "reasons":[
        "required"
      ]
    })
  }
  if(!req.body.cin) {
    errors.errors.push({
      "field": "cin",
      "reasons":[
        "required"
      ]
    })
  }
  if(typeof(req.body.cin) != 'number') {
    errors.errors.push({
      "field": "cin",
      "reasons":[
        "required",
        "Not integer"
      ]
    })
  } 
  if(!req.body.registration_date) {
    errors.errors.push({
      "field": "registration_date",
      "reasons":[
        "required"
      ]
    })
  }
  if(dateFormat(req.body.registration_date, "yyyy") != new Date().getFullYear()){
    errors.errors.push({
      "field": "registration_date",
      "reasons":[
        "required",
        "Invalid range"
      ]
    })
  }
  if(!req.body.corporate_body_name) {
    errors.errors.push({
      "field": "corporate_body_name",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.br_section) {
    errors.errors.push({
      "field": "br_section",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.br_insertion) {
    errors.errors.push({
      "field": "br_insertion",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.text) {
    errors.errors.push({
      "field": "text",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.street) {
    errors.errors.push({
      "field": "street",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.postal_code) {
    errors.errors.push({
      "field": "postal_code",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.city) {
    errors.errors.push({
      "field": "city",
      "reasons":[
        "required"
      ]
    })
  };

  if(errors.errors.length != 0){
    res.statusCode = 422;
    res.send(errors);
    return;
  }

  //Gerring number for bulletin_issue
  const bul = await sequelize.query('SELECT number FROM ov.bulletin_issues WHERE year = 2021 ORDER BY number DESC LIMIT 1');
  num = bul[0][0].number + 1;

  //Creating row for bulletin issues
  const [results, metadata] = await sequelize.query(`INSERT INTO ov.bulletin_issues (year, number, 
    published_at, created_at, updated_at) VALUES (${new Date().getFullYear()}, ${num}, '${today}',
    '${today}', '${today}') RETURNING id;`);
  var bulletin_issue_id = results[0].id;

  //Creating row for raw issues
  const [resultsRaw, metadataRaw] = await sequelize.query(`INSERT INTO ov.raw_issues (bulletin_issue_id,
    file_name, content, created_at, updated_at) VALUES (${bulletin_issue_id}, '-', '-','${today}',
    '${today}') RETURNING id;`);
  var raw_issue_id = resultsRaw[0].id;

  //Creating row for or podanie issues
  const [resIssues, metaIssues] = await sequelize.query(`INSERT INTO ov.or_podanie_issues (raw_issue_id,
    bulletin_issue_id, br_court_name, kind_name, cin, registration_date, corporate_body_name,
    br_section, br_insertion, text, street, postal_code, city, created_at, updated_at, address_line,
    br_mark, br_court_code, kind_code)
    VALUES (${raw_issue_id}, ${bulletin_issue_id}, '${req.body.br_court_name}', '${req.body.kind_name}',
    ${Number(req.body.cin)}, '${req.body.registration_date}', '${req.body.corporate_body_name}', '${req.body.br_section}',
    '${req.body.br_insertion}', '${req.body.text}', '${req.body.street}', 
    '${req.body.postal_code}', '${req.body.city}', '${today}', '${today}', `+ 
    `'${req.body.street}, ${req.body.postal_code} ${req.body.city}'`+`, '-', '-', '-') RETURNING id;`);


    const [toSendRes, met] = await sequelize.query(`SELECT id, br_court_name, kind_name, cin, registration_date, 
    corporate_body_name, br_section, text, street, postal_code, city FROM ov.or_podanie_issues
    WHERE id = ${resIssues[0].id}`);

    res.statusCode = 201;
    res.send(
      {
        "response": toSendRes[0]
      }
    );

});

app.delete('/v1/ov/submissions/:tagID', async(req, res) => {
  const [results, metadata] = await sequelize.query("DELETE FROM ov.bulletin_issues WHERE id =" + req.params.tagID);

  if(!metadata.rowCount){
    res.statusCode = 404
    res.send(
      {
        "error":{
          "message": "Zaznam neexistuje"
        }
      }
    )
  }
  else{
    res.statusCode = 200;
    res.send('')
  }
});

app.get('/v1/companies', async(req, res) => {
  let page = req.query.page;
  let per_page = req.query.per_page;
  let order_by = req.query.order_by;
  let order_type = req.query.order_type;
  let last_update_lte = req.query.last_update_lte;
  let last_update_gte = req.query.last_update_gte;
  let query = req.query.query;
  if(!page) page = 1
  if(!per_page) per_page = 10
  if(!order_by) order_by = "cin"
  if(!order_type) order_type = "ASC"
  if(!last_update_lte) last_update_lte = '3000-06-17';
  else{
    const[foo, bar] = await sequelize.query(`select TO_DATE('${req.query.last_update_lte}', 'iso')`)
    last_update_lte = foo[0].to_date;
  }
  if(!last_update_gte) last_update_gte = '1000-01-01';
  else{
    const[foo, bar] = await sequelize.query(`select TO_DATE('${req.query.last_update_gte}', 'iso')`)
    last_update_gte = foo[0].to_date;
  }
  

  lower_border = Number(per_page) * (Number(page) - 1);

  let whereStatement = `  AND (name LIKE '%${query}%' 
  OR address_line LIKE '%${query}%')`
  if(!query) whereStatement = ""


  let theQuery = `
  SELECT results.cin, name, br_section, address_line, last_update,
  results.or_podanie_issues_count,
  results.likvidator_issues_count,
  results.konkurz_vyrovnanie_issues_count,
  results.znizenie_imania_issues_count,
  results.konkurz_restrukturalizacia_actors_count
  FROM(
  (SELECT cin, name, br_section, address_line, last_update
  FROM ov.companies) as com
  LEFT JOIN
  (SELECT count(company_id) as or_podanie_issues_count, cin as id1 FROM ov.or_podanie_issues GROUP BY cin) as c1
  on com.cin = c1.id1
  LEFT JOIN
  (SELECT count(company_id) as likvidator_issues_count, cin as id2 FROM ov.likvidator_issues GROUP BY cin) as c2
  on com.cin = c2.id2
  LEFT JOIN
  (SELECT count(company_id) as konkurz_vyrovnanie_issues_count, cin as id3 FROM ov.konkurz_vyrovnanie_issues GROUP BY cin) as c3
  on com.cin = c3.id3
  LEFT JOIN
  (SELECT count(company_id) as znizenie_imania_issues_count, cin as id4 FROM ov.znizenie_imania_issues GROUP BY cin) as c4
  on com.cin = c4.id4
  LEFT JOIN
  (SELECT count(company_id) as konkurz_restrukturalizacia_actors_count, cin as id5 FROM ov.konkurz_restrukturalizacia_actors GROUP BY cin) as c5
  on com.cin = c5.id5
  ) as results
  WHERE last_update < '${last_update_lte}'::date 
  AND last_update > '${last_update_gte}'::date
  ` + whereStatement + `ORDER BY ${order_by} ${order_type} offset ${lower_border} ROWS FETCH FIRST ${per_page} rows only`


  const [results, metadata] = await sequelize.query(theQuery);

  const [totalRes, meta] = await sequelize.query(`
    SELECT count(cin)
    FROM ov.companies
    WHERE last_update < '${last_update_lte}'::date 
    AND last_update > '${last_update_gte}'::date`
    + whereStatement);

  toSend ={
    "items": results,
    "metadata": {
      "page": Number(page),
      "per_page": Number(per_page),
      "pages": Math.ceil(totalRes[0].count / per_page),
      "total": Number(totalRes[0].count)
    }
  }

  res.send(toSend);

});

//ZADANIE 4
app.delete('/v2/ov/submissions/:tagID', async(req, res) => {
  db.bulletin_issues.destroy({
    where: {
      id: req.params.tagID
    }
  }).then(data =>{
    if(!data){
      res.statusCode = 404
      res.send(
        {
          "error":{
            "message": "Zaznam neexistuje"
          }
        }
      )
    }
    else{
      res.sendStatus = 204
    }
  }).catch(err=>{
    console.log(err)
    res.send(err)
  })
});

app.get('/v2/ov/submissions', async(req, res) => {
  let page = req.query.page;
  let per_page = req.query.per_page;
  let order_by = req.query.order_by;
  let order_type = req.query.order_type;
  let registration_date_lte = req.query.registration_date_lte;
  let registration_date_gte = req.query.registration_date_gte;
  let query = req.query.query;
  if(!page) page = 1
  if(!per_page) per_page = 10
  if(!order_by) order_by = "id"
  if(!order_type) order_type = "ASC"
  if(!registration_date_lte) registration_date_lte = null;
  else
    registration_date_lte = sequelize.fn('TO_DATE', req.query.registration_date_lte, 'iso')
  if(!registration_date_gte) registration_date_gte = null;
  else
    registration_date_gte = sequelize.fn('TO_DATE', req.query.registration_date_gte, 'iso')

  lower_border = Number(per_page) * (Number(page) - 1);

  let whereStatement = {}
  if(query){
    if(isNaN(query)){
      whereStatement = {
        [Op.or]:[
          {
            corporate_body_name:{
              [Op.substring]: query,
            }
          },
          {
            city:{
              [Op.substring]: query,
            }
          }
        ]
      }
    }
    else{
      whereStatement = {
        [Op.or]:[
          sequelize.where(
            sequelize.cast(sequelize.col('cin'), 'TEXT'),
            {[Op.like]: query}
          ),
        ]
      }
    }
  }

  if(registration_date_lte && registration_date_gte){
    whereStatement['registration_date'] = {
      [Op.lt]:  sequelize.cast(registration_date_lte, 'DATE'),
      [Op.gt]:  sequelize.cast(registration_date_gte, 'DATE')
    }
  }
  else if(registration_date_lte){
    whereStatement['registration_date'] = {
      [Op.lt]:  sequelize.cast(registration_date_lte, 'DATE')
    }
  }
  else if(registration_date_gte){
    whereStatement['registration_date'] = {
      [Op.gt]:  sequelize.cast(registration_date_gte, 'DATE')
    }
  }


  db["or_podanie_issues"].findAndCountAll({
    attributes: ["id", "br_court_name", "kind_name", "cin", "registration_date", "corporate_body_name", "br_section", "text", "street", "postal_code", "city" ],
    where:whereStatement,
    order: [[order_by, order_type + ' NULLS last']],
    limit: per_page,
    offset: lower_border,

  }).then(data=>{
    toSend ={
      "items": data['rows'],
      "metadata": {
        "page": Number(page),
        "per_page": Number(per_page),
        "pages": Math.ceil(data['count'] / per_page),
        "total": data['count']
      }
    }
    res.send(toSend)
  }).catch(err =>{
    console.log(err)
    res.send(err)
  })
})

app.get('/v2/ov/submissions/:tagID', async(req, res) => {
  db["or_podanie_issues"].findByPk(req.params.tagID, {
    attributes: ["id", "br_court_name", "kind_name", "cin", "registration_date", "corporate_body_name", "br_section", "text", "street", "postal_code", "city" ]
  }).then(data=>{
    res.send({"response":data})
  }).catch(err =>{
    console.log(err)
    res.sendStatus(404)
  })
})

app.post('/v2/ov/submissions', async(req, res) =>{
  //Getting todays date
  let today = dateFormat(new Date(), "isoDateTime");

  //Validations
  errors = {
    "errors": []
  }
  if(!req.body.br_court_name) {
    errors.errors.push({
      "field": "br_court_name",
      "reasons":[
        "required"
      ]
    })
  }
  if(!req.body.kind_name) {
    errors.errors.push({
      "field": "kind_name",
      "reasons":[
        "required"
      ]
    })
  }
  if(!req.body.cin) {
    errors.errors.push({
      "field": "cin",
      "reasons":[
        "required"
      ]
    })
  }
  if(typeof(req.body.cin) != 'number') {
    errors.errors.push({
      "field": "cin",
      "reasons":[
        "required",
        "Not integer"
      ]
    })
  } 
  if(!req.body.registration_date) {
    errors.errors.push({
      "field": "registration_date",
      "reasons":[
        "required"
      ]
    })
  }
  if(dateFormat(req.body.registration_date, "yyyy") != new Date().getFullYear()){
    errors.errors.push({
      "field": "registration_date",
      "reasons":[
        "required",
        "Invalid range"
      ]
    })
  }
  if(!req.body.corporate_body_name) {
    errors.errors.push({
      "field": "corporate_body_name",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.br_section) {
    errors.errors.push({
      "field": "br_section",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.br_insertion) {
    errors.errors.push({
      "field": "br_insertion",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.text) {
    errors.errors.push({
      "field": "text",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.street) {
    errors.errors.push({
      "field": "street",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.postal_code) {
    errors.errors.push({
      "field": "postal_code",
      "reasons":[
        "required"
      ]
    })
  };
  if(!req.body.city) {
    errors.errors.push({
      "field": "city",
      "reasons":[
        "required"
      ]
    })
  };

  if(errors.errors.length != 0){
    res.statusCode = 422;
    res.send(errors);
    return;
  }

  //Getting number for bulletin_issue
  db["bulletin_issues"].findOne( {
    attributes: ["number"],
    where:{year: new Date().getFullYear()},
    order: [["number", "DESC"]]
  }).then(data=>{
    num = 1 + data["number"]
    //Creating bulletin issue
    db["bulletin_issues"].create({
      year: new Date().getFullYear(),
      number: num,
      published_at: today,
      created_at: today,
      updated_at: today
    }).then(data=>{
      //Creationg raw issue
      db["raw_issues"].create({
        bulletin_issue_id: data["id"],
        file_name: '-', 
        content: '-', 
        created_at: today, 
        updated_at: today,
      }).then(data =>{
        //Creating row for or_padanie_issues
        db["or_podanie_issues"].create({
          raw_issue_id: data["id"],
          bulletin_issue_id: data["bulletin_issue_id"], 
          br_court_name: req.body.br_court_name, 
          kind_name:req.body.kind_name, 
          cin: Number(req.body.cin), 
          registration_date: req.body.registration_date, 
          corporate_body_name: req.body.corporate_body_name,
          br_section: req.body.br_section, 
          br_insertion: req.body.br_insertion, 
          text: req.body.text, 
          street: req.body.street, 
          postal_code: req.body.postal_code, 
          city: req.body.city, 
          created_at: today, 
          updated_at: today, 
          address_line: `'${req.body.street}, ${req.body.postal_code} ${req.body.city}'`,
          br_mark: '-', 
          br_court_code: '-', 
          kind_code: '-'
        }).then(data=>{
          res.statusCode = 201
          res.send({"response":data})
        }).catch(err=>{
          console.log(err)
          res.send(err)
        })
      }).catch(err=>{
        console.log(err)
        res.send(err)
      })
    }).catch(err =>{
      console.log(err)
      res.send(err)
    })
  }).catch(err =>{
    console.log(err)
    res.send(err)
  })
});

app.put('/v2/ov/submissions/:tagID', async(req, res) => {
  //Getting todays date
  let today = dateFormat(new Date(), "isoDateTime");
  //Getting edited model
  db["or_podanie_issues"].findByPk(req.params.tagID, {
    attributes: ["id", "br_court_name", "kind_name", "cin", "registration_date", "corporate_body_name", "br_section", "text", "street", "postal_code", "city" ]
  }).then(data=>{
    //Validations
    errors = {
      "errors": []
    }
    toChange = []
    if(req.body.br_court_name){
      if(typeof(req.body.br_court_name) != "string") {
        errors.errors.push({
          "field": "br_court_name",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("br_court_name")
      data.br_court_name = req.body.br_court_name
    }
    if(req.body.kind_name){
      console.log(`We got a name and its ${req.body.kind_name} ${typeof(req.body.kind_name)}`)
      if(typeof(req.body.kind_name) != "string") {
        errors.errors.push({
          "field": "kind_name",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("kind_name")
      data.kind_name = req.body.kind_name
    }
    if(req.body.cin){
      if(typeof(req.body.cin) != 'number') {
        errors.errors.push({
          "field": "cin",
          "reasons":[
            "Not integer"
          ]
        })
      } 
      toChange.push("cin")
      data.cin = req.body.cin
    }
    if(req.body.registration_date){
      if(dateFormat(req.body.registration_date, "yyyy") != new Date().getFullYear()){
        errors.errors.push({
          "field": "registration_date",
          "reasons":[
            "Invalid range"
          ]
        })
      }
      toChange.push("registration_date")
      data.registration_date = req.body.registration_date
    }
    if(req.body.corporate_body_name){
      if(typeof(req.body.corporate_body_name) != "string") {
        errors.errors.push({
          "field": "corporate_body_name",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("corporate_body_name")
      data.corporate_body_name = req.body.corporate_body_name
    };
    if(req.body.br_section){
      if(typeof(req.body.br_section) != "string") {
        errors.errors.push({
          "field": "br_section",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("br_section")
      data.br_section = req.body.br_section
    };
    if(req.body.br_insertion){
      if(typeof(req.body.br_insertion) != "string") {
        errors.errors.push({
          "field": "br_insertion",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("br_insertion")
      data.br_insertion = req.body.br_insertion
    };
    if(req.body.text){
      if(typeof(req.body.text) != "string") {
        errors.errors.push({
          "field": "text",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("text")
      data.text = req.body.text
    };
    if(req.body.street){
      if(typeof(req.body.street) != "string") {
        errors.errors.push({
          "field": "street",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("street")
      data.street = req.body.street
    };
    if(req.body.postal_code){
      if(typeof(req.body.postal_code) != "string") {
        errors.errors.push({
          "field": "postal_code",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("postal_code")
      data.postal_code = req.body.postal_code
    };
    if(req.body.city){
      if(typeof(req.body.city) != "string") {
        errors.errors.push({
          "field": "city",
          "reasons":[
            "not_string"
          ]
        })
      }
      toChange.push("city")
      data.city = req.body.city
    };

    if(errors.errors.length != 0){
      res.statusCode = 422;
      res.send(errors);
      return;
    }
    //saving changes
    data.save({fields: toChange})
    res.send({"response": data})
  }).catch(err =>{
    console.log(err)
    res.sendStatus(404)
  })
});

app.get('/v2/companies', async(req, res) => {
  let page = req.query.page;
  let per_page = req.query.per_page;
  let order_by = req.query.order_by;
  let order_type = req.query.order_type;
  let last_update_lte = req.query.last_update_lte;
  let last_update_gte = req.query.last_update_gte;
  let query = req.query.query;
  if(!page) page = 1
  if(!per_page) per_page = 10
  if(!order_by) order_by = "cin"
  if(!order_type) order_type = "ASC"
  if(!last_update_lte) last_update_lte = null;
  else
    last_update_lte = sequelize.fn('TO_DATE', req.query.last_update_lte, 'iso')
  if(!last_update_gte) last_update_gte = null;
  else
    last_update_gte = sequelize.fn('TO_DATE', req.query.last_update_gte, 'iso')

  lower_border = Number(per_page) * (Number(page) - 1);

  let whereStatement = {}
  if(query){
    if(isNaN(query)){
      whereStatement = {
        [Op.or]:[
          {
            corporate_body_name:{
              [Op.substring]: query,
            }
          },
          {
            city:{
              [Op.substring]: query,
            }
          }
        ]
      }
    }
    else{
      whereStatement = {
        [Op.or]:[
          sequelize.where(
            sequelize.cast(sequelize.col('cin'), 'TEXT'),
            {[Op.like]: query}
          ),
        ]
      }
    }
  }

  if(last_update_lte && last_update_gte){
    whereStatement['registration_date'] = {
      [Op.lt]:  sequelize.cast(last_update_lte, 'DATE'),
      [Op.gt]:  sequelize.cast(last_update_gte, 'DATE')
    }
  }
  else if(last_update_lte){
    whereStatement['registration_date'] = {
      [Op.lt]:  sequelize.cast(last_update_lte, 'DATE')
    }
  }
  else if(last_update_gte){
    whereStatement['registration_date'] = {
      [Op.gt]:  sequelize.cast(last_update_gte, 'DATE')
    }
  }

  db["companies"].hasMany(db["or_podanie_issues"], {
    foreignKey: 'cin'
  })
  db["or_podanie_issues"].belongsTo(db["companies"], {
    foreignKey: 'cin'
  })

  db["companies"].hasMany(db["znizenie_imania_issues"], {
    foreignKey: 'cin'
  })
  db["znizenie_imania_issues"].belongsTo(db["companies"], {
    foreignKey: 'cin'
  })

  db["companies"].hasMany(db["likvidator_issues"], {
    foreignKey: 'cin'
  })
  db["likvidator_issues"].belongsTo(db["companies"], {
    foreignKey: 'cin'
  })

  db["companies"].hasMany(db["konkurz_vyrovnanie_issues"], {
    foreignKey: 'cin'
  })
  db["konkurz_vyrovnanie_issues"].belongsTo(db["companies"], {
    foreignKey: 'cin'
  })

  db["companies"].hasMany(db["konkurz_restrukturalizacia_actors"], {
    foreignKey: 'cin'
  })
  db["konkurz_restrukturalizacia_actors"].belongsTo(db["companies"], {
    foreignKey: 'cin'
  })

  db["companies"].findAndCountAll({
    attributes: ["cin", "name", "br_section", "address_line", "last_update"],
    where:whereStatement,
    order: [[order_by, order_type + ' NULLS last']],
    limit: per_page,
    offset: lower_border,
    include:[
      {
        model: db["or_podanie_issues"],
        attributes: ['cin'],
        required: false,
      },
      {
        model: db["znizenie_imania_issues"],
        attributes: ['cin'],
        required: false,
      },
      {
        model: db["likvidator_issues"],
        attributes: ['cin'],
        required: false,
      },
      {
        model: db["konkurz_vyrovnanie_issues"],
        attributes: ['cin'],
        required: false,
      },
      {
        model: db["konkurz_restrukturalizacia_actors"],
        attributes: ['cin'],
        required: false,
      },
    ],




  }).then(companies=>{

    toSend ={
      "metadata": {
        "page": Number(page),
        "per_page": Number(per_page),
        "pages": Math.ceil(companies['count'] / per_page),
        "total": companies['count']
      },
      "items": companies['rows'],
    }
    res.send(toSend)
  }).catch(err =>{
    console.log(err)
    res.send(err)
  })

  //let theQuery = `
  //SELECT results.cin, name, br_section, address_line, last_update,
  //results.or_podanie_issues_count,
  //results.likvidator_issues_count,
  //results.konkurz_vyrovnanie_issues_count,
  //results.znizenie_imania_issues_count,
  //results.konkurz_restrukturalizacia_actors_count
  //FROM(
  //(SELECT cin, name, br_section, address_line, last_update
  //FROM ov.companies) as com
  //LEFT JOIN
  //(SELECT count(company_id) as or_podanie_issues_count, cin as id1 FROM ov.or_podanie_issues GROUP BY cin) as c1
  //on com.cin = c1.id1
  //LEFT JOIN
  //(SELECT count(company_id) as likvidator_issues_count, cin as id2 FROM ov.likvidator_issues GROUP BY cin) as c2
  //on com.cin = c2.id2
  //LEFT JOIN
  //(SELECT count(company_id) as konkurz_vyrovnanie_issues_count, cin as id3 FROM ov.konkurz_vyrovnanie_issues GROUP BY cin) as c3
  //on com.cin = c3.id3
  //LEFT JOIN
  //(SELECT count(company_id) as znizenie_imania_issues_count, cin as id4 FROM ov.znizenie_imania_issues GROUP BY cin) as c4
  //on com.cin = c4.id4
  //LEFT JOIN
  //(SELECT count(company_id) as konkurz_restrukturalizacia_actors_count, cin as id5 FROM ov.konkurz_restrukturalizacia_actors GROUP BY cin) as c5
  //on com.cin = c5.id5
  //) as results
  //WHERE last_update < '${last_update_lte}'::date 
  //AND last_update > '${last_update_gte}'::date
  //` + whereStatement + `ORDER BY ${order_by} ${order_type} offset ${lower_border} ROWS FETCH FIRST ${per_page} rows only`
//
//
  //const [results, metadata] = await sequelize.query(theQuery);
//
  //const [totalRes, meta] = await sequelize.query(`
  //  SELECT count(cin)
  //  FROM ov.companies
  //  WHERE last_update < '${last_update_lte}'::date 
  //  AND last_update > '${last_update_gte}'::date`
  //  + whereStatement);
//
  //toSend ={
  //  "items": results,
  //  "metadata": {
  //    "page": Number(page),
  //    "per_page": Number(per_page),
  //    "pages": Math.ceil(totalRes[0].count / per_page),
  //    "total": Number(totalRes[0].count)
  //  }
  //}
//
  //res.send(toSend);

});


app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})
