'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('konkurz_restrukturalizacia_actors', {
      cin: DataTypes.BIGINT
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('konkurz_restrukturalizacia_actors');
  }
};