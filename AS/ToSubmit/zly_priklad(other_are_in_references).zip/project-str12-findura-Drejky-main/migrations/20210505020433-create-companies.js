'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('companies', {
      cin: {
        type: DataTypes.BIGINT,
        primaryKey:true,
        allowNull: false,
      },
      name: DataTypes.STRING,
      br_section: DataTypes.STRING,
      address_line: DataTypes.STRING,
      last_update: DataTypes.DATE,
      created_at: DataTypes.DATE,
      updated_at: DataTypes.DATE
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('companies');
  }
};