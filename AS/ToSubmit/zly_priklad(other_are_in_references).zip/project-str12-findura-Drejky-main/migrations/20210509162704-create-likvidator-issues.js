'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('likvidator_issues', {
      cin: DataTypes.BIGINT
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('likvidator_issues');
  }
};