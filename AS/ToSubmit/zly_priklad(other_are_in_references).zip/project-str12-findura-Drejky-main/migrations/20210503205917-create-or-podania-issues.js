'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('or_podania_issues', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      bulletin_issue_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      raw_issue_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      br_mark: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      br_court_code: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      br_court_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      kind_code: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      kind_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      cin: DataTypes.BIGINT,
      registration_date: DataTypes.DATE,
      corporate_body_name: DataTypes.STRING,
      br_section: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      br_insertion: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      text: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
      },
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('or_podania_issues');
  }
};