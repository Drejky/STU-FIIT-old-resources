'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    /**
     * Add altering commands here.
     *
     * Example:
     * await queryInterface.createTable('users', { id: Sequelize.INTEGER });
     */
    const [results, metadata] = await queryInterface.sequelize.query(`
    --Table create
    CREATE TABLE ov.companies (
      cin bigint NOT NULL PRIMARY KEY,
      name varchar,
      br_section varchar,
      address_line varchar,
      last_update TIMESTAMP WITHOUT TIME ZONE,
      created_at TIMESTAMP WITHOUT TIME ZONE,
      updated_at TIMESTAMP WITHOUT TIME ZONE
    ); 
    --First table insert
    INSERT INTO ov.companies(
      cin, name, br_section, address_line, last_update, created_at, updated_at
    ) 
    SELECT  cin, corporate_body_name, br_section, 
    address_line, updated_at
    , current_timestamp, current_timestamp
    from (Select *, 
    rank() over (PARTITION BY cin order by updated_at desc) as latest
    from ov.or_podanie_issues) as tab
    where not exists(
      select cin from ov.companies
      where tab.cin = ov.companies.cin
    )and cin is not null and latest = 1;
    --Second table insert
    INSERT INTO ov.companies(
      cin, name, br_section, address_line, last_update, created_at, updated_at
    ) 
    SELECT  cin, corporate_body_name, br_section, 
    CONCAT(street,', ',postal_code, ' ', city), updated_at
    , current_timestamp, current_timestamp
    from
    (Select *,
     rank() over (PARTITION BY cin order by updated_at desc) as latest
     from ov.likvidator_issues) as tab
    where not exists(
      select cin from ov.companies
      where tab.cin = ov.companies.cin
    )and cin is not null and latest = 1;
    --Third table insert
    INSERT INTO ov.companies(
      cin, name, br_section, address_line, last_update, created_at, updated_at
    ) 
    SELECT  cin, corporate_body_name, null, 
    CONCAT(street,', ',postal_code, ' ', city), updated_at
    , current_timestamp, current_timestamp
    from
    (Select *,
     rank() over (PARTITION BY cin order by updated_at desc) as latest
     from ov.konkurz_vyrovnanie_issues) as tab
    where not exists(
      select cin from ov.companies
      where tab.cin = ov.companies.cin
    )and cin is not null and latest = 1;
    --Fourth table insert
    INSERT INTO ov.companies(
      cin, name, br_section, address_line, last_update, created_at, updated_at
    ) 
    SELECT  cin, corporate_body_name, null, 
    CONCAT(street,', ',postal_code, ' ', city), updated_at
    , current_timestamp, current_timestamp
    from
    (Select *,
     rank() over (PARTITION BY cin order by updated_at desc) as latest
     from ov.znizenie_imania_issues) as tab
    where not exists(
      select cin from ov.companies
      where tab.cin = ov.companies.cin
    )and cin is not null and latest = 1;
    --Fifth table insert
    INSERT INTO ov.companies(
      cin, name, br_section, address_line, last_update, created_at, updated_at
    ) 
    SELECT  cin, corporate_body_name, null, 
    CONCAT(street,', ',postal_code, ' ', city), updated_at
    , current_timestamp, current_timestamp
    from
    (Select *,
     rank() over (PARTITION BY cin order by updated_at desc) as latest
     from ov.konkurz_restrukturalizacia_actors) as tab
    where not exists(
      select cin from ov.companies
      where tab.cin = ov.companies.cin
    )and cin is not null and latest = 1;
    --First column add
    ALTER TABLE ov.or_podanie_issues
    ADD company_id bigint;
    UPDATE ov.or_podanie_issues
    SET company_id = cin;
    ALTER TABLE ov.or_podanie_issues
    ADD FOREIGN KEY (company_id) references ov.companies(cin);
    --Second column add
    ALTER TABLE ov.likvidator_issues
    ADD company_id bigint;
    UPDATE ov.likvidator_issues
    SET company_id = cin;
    ALTER TABLE ov.likvidator_issues
    ADD FOREIGN KEY (company_id) references ov.companies(cin);
    --Third column add
    ALTER TABLE ov.konkurz_vyrovnanie_issues
    ADD company_id bigint;
    UPDATE ov.konkurz_vyrovnanie_issues
    SET company_id = cin;
    ALTER TABLE ov.konkurz_vyrovnanie_issues
    ADD FOREIGN KEY (company_id) references ov.companies(cin);
    --Fourth column add
    ALTER TABLE ov.znizenie_imania_issues
    ADD company_id bigint;
    UPDATE ov.znizenie_imania_issues
    SET company_id = cin;
    ALTER TABLE ov.znizenie_imania_issues
    ADD FOREIGN KEY (company_id) references ov.companies(cin);
    --Fifth column add
    ALTER TABLE ov.konkurz_restrukturalizacia_actors
    ADD company_id bigint;
    UPDATE ov.konkurz_restrukturalizacia_actors
    SET company_id = cin;
    ALTER TABLE ov.konkurz_restrukturalizacia_actors
    ADD FOREIGN KEY (company_id) references ov.companies(cin);
    `)
    return results;
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
     const [results, metadata] = await queryInterface.sequelize.query(`
     --UNDO command
     ALTER TABLE ov.or_podanie_issues
     DROP COLUMN company_id;
     ALTER TABLE ov.likvidator_issues
     DROP COLUMN company_id;
     ALTER TABLE ov.konkurz_vyrovnanie_issues
     DROP COLUMN company_id;
     ALTER TABLE ov.znizenie_imania_issues
     DROP COLUMN company_id;
     ALTER TABLE ov.konkurz_restrukturalizacia_actors
     DROP COLUMN company_id;
     DROP TABLE ov.companies;
     `)
     return results;
  }
};

/*
--uwu
INSERT INTO ov.company (cin, name, br_section,address_line, last_update,created_at,updated_at)
SELECT DISTINCT ON (cin) cin, 
	   corporate_body_name, 
	   br_section, 
	   address_line, 
	   MAX(updated_at) OVER (PARTITION BY cin ORDER BY updated_at DESC RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW), 
	   current_timestamp, 
	   current_timestamp
FROM ov.or_podanie_issues
WHERE cin != 0;
*/